import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-quick-stats',
  templateUrl: './quick-stats.component.html',
  styleUrls: ['./quick-stats.component.scss'],
  standalone: true,
  imports: [IonicModule],
})
export class QuickStatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

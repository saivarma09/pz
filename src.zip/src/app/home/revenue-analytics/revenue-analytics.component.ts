import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-revenue-analytics',
  templateUrl: './revenue-analytics.component.html',
  styleUrls: ['./revenue-analytics.component.scss'],
  standalone: true,
  imports: [IonicModule],
})
export class RevenueAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

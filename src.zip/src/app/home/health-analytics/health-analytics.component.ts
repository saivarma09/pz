import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-health-analytics',
  templateUrl: './health-analytics.component.html',
  styleUrls: ['./health-analytics.component.scss'],
  standalone: true,
  imports: [IonicModule],
})
export class HealthAnalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
